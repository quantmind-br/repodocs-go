# API Reference

This is the API reference documentation.

## Functions

### doSomething()

Does something useful.
