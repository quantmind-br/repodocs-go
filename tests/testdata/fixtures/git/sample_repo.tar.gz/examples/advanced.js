/**
 * Advanced Usage Example
 *
 * This example demonstrates advanced features including:
 * - Event handling
 * - Error recovery
 * - Configuration management
 */

const SampleProject = require('sample-project');

async function advancedExample() {
  const client = new SampleProject({
    apiKey: process.env.SAMPLE_API_KEY,
    timeout: 10000,
    retries: 3,
    debug: false
  });

  // Set up event handlers
  client.on('connected', () => {
    console.log('Event: Connected');
  });

  client.on('disconnected', () => {
    console.log('Event: Disconnected');
  });

  client.on('error', (error) => {
    console.error('Event: Error', error.message);
  });

  client.on('data', (data) => {
    console.log('Event: Data received', data);
  });

  try {
    // Connect with retry logic
    await connectWithRetry(client);

    // Process data
    await processData(client);

  } finally {
    await client.close();
  }
}

async function connectWithRetry(client, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      await client.connect();
      return;
    } catch (error) {
      console.error(`Connection attempt ${i + 1} failed:`, error.message);
      if (i === maxRetries - 1) throw error;
      await sleep(1000 * (i + 1)); // Exponential backoff
    }
  }
}

async function processData(client) {
  const data = { message: 'Hello, World!' };
  const response = await client.send(data);
  console.log('Response:', response);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

advancedExample().catch(console.error);
