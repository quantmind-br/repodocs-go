/**
 * Basic Usage Example
 *
 * This example demonstrates basic usage of the Sample Project.
 */

const SampleProject = require('sample-project');

async function main() {
  // Create a new client instance
  const client = new SampleProject({
    apiKey: process.env.SAMPLE_API_KEY || 'demo-key',
    debug: true
  });

  try {
    // Connect to the API
    console.log('Connecting...');
    await client.connect();
    console.log('Connected successfully');

    // Run the main logic
    console.log('Running...');
    const result = await client.run();
    console.log('Result:', result);

  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  } finally {
    // Always close the connection
    await client.close();
    console.log('Disconnected');
  }
}

main();
